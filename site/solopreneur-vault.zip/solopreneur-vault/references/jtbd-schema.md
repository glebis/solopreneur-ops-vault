# JTBD JSON Schema

```json
{
  "name": "project-slug",
  "hook": "One sentence: what this is for whom.",
  "jtbd": {
    "situation": "When [specific context/trigger]...",
    "motivation": "I want to [action/goal]...",
    "outcome": "So I can [measurable result]..."
  },
  "problem": {
    "what_hurts": "Specific pain with evidence.",
    "cost_today": "What the pain costs (time, money, stress)."
  },
  "needs": {
    "functional": ["what it must do"],
    "emotional": ["how user wants to feel"]
  },
  "switch_forces": {
    "push": "Frustration with today.",
    "pull": "Attraction to new solution.",
    "habit": "What keeps them stuck.",
    "anxiety": "What they fear about switching."
  },
  "outputs": ["what the project produces"],
  "before_after": {
    "before": "Visible + felt state before.",
    "after": "Visible + felt state after."
  },
  "evidence": {
    "source": "interview",
    "quotes": ["verbatim quotes"],
    "weaknesses": ["dimensions that scored low"]
  },
  "guardrails": ["what it must NOT do"],
  "open_questions": ["unresolved follow-ups"],
  "version": 1
}
```
