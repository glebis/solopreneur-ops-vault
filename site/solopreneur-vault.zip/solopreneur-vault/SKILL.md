---
name: solopreneur-vault
description: This skill should be used when creating a personal operations vault for solopreneurs, freelancers, or independent educators. Initializes an Obsidian vault with behavioral activation framework, Maps of Content, deep research, daily dashboard with Dataview, and deploys as an Astro site with Tufte design to Vercel. Triggers on "create a vault", "solopreneur ops", "build me a knowledge base for my business", "I need a daily dashboard", "set up my operations system".
---

# Solopreneur Vault

End-to-end pipeline: JTBD interview → Obsidian vault → deep research → Astro site → Vercel deploy → scheduled agents.

## Pipeline

```
Phase 1: Interview (5 min)   → JTBD brief in meta/
Phase 2: Vault (3 min)       → MOCs, frameworks, templates, dashboard
Phase 3: Research (5 min)    → 3+ parallel deep research agents
Phase 4: Site (3 min)        → Astro + Tufte design + sparklines
Phase 5: Deploy (2 min)      → Vercel + custom domain + GitHub
Phase 6: Automate (2 min)    → Scheduled research agents
```

## Phase 1: JTBD Interview

Conduct a focused interview to understand the solopreneur's job-to-be-done. Ask one question at a time. Push back on vague answers.

### Core Questions

1. **What do you do?** — Role, products, market. One sentence.
2. **What's your bottleneck?** — The specific pain that blocks growth.
3. **Tell me about the last time this bottleneck hurt you.** — Concrete situation, not abstract.
4. **What does success look like?** — The outcome, not features.
5. **What would make you stop using this system?** — The abandonment trigger.

### Switch Forces (quick burst)

- **Push**: What's frustrating about today?
- **Pull**: What does the ideal morning look like?
- **Habit**: What fills the void instead of productive action?
- **Anxiety**: What would make you abandon this?

### Extended Interview: Business Strategy (optional, after core)

If the user wants deeper business mapping, add these sections (adapted from Ricardo Brito's solopreneur accelerator):

**Foundations:** What motivated you to start this business? Why is it important? Why now?

**Vision:** Mission statement? Vision statement? Core values? How do you define success?

**Current Status:** What stage (idea/early/established)? Primary offering? Pricing structure? How do clients find you?

**Goals:** Audacious goals for 1 year, 3 years, 10 years? Top 3 problems for next 90 days? Three things that need to change?

**Financial:** Monthly business budget? Minimum monthly income needed? Are you making enough revenue? Cost of selling?

**Marketing:** Which tactics have worked? Active social platforms? Content strategy? Current sales process?

**Barriers:** Biggest barriers? Current struggles? Tasks that feel overwhelming?

**Systems:** What tools do you use (scheduling, invoicing, CRM)? Marketing tools? Automation?

Capture answers in `templates/Business Strategy Questionnaire.md` and use them to pre-populate Business Model Canvas, Lean Canvas, and Business Metrics frameworks.

### Output

Save `meta/jtbd.json` (see `references/jtbd-schema.md`) and `meta/one-pager.md`.

## Phase 2: Vault Structure

Create this directory structure in the current working directory:

```
├── MOC/                    # Maps of Content
│   ├── 00 — Home.md        # Main navigation hub
│   ├── Sales Pipeline.md   # Visibility → leads → conversion
│   ├── Frameworks.md       # All thinking tools
│   ├── Market Intelligence.md
│   ├── Content Engine.md
│   └── Agent Ops.md        # What agents do automatically
├── frameworks/             # One file per framework
├── research/               # Agent-generated research
├── tasks/                  # Dataview-compatible task files
├── templates/              # Context Interview, etc.
├── agents/                 # Agent docs
├── scripts/                # deploy-site.sh
├── meta/                   # JTBD, process research
├── Daily Dashboard.md      # Dataview queries
└── site/                   # Astro site (Phase 4)
```

### Core Frameworks (always create, adapt to user context)

1. **Behavioral Activation** — Action → motivation. Include avoidance mapping table from interview.
2. **Infinite Sales Cycle** — Create → Publish → Engage → Convert → Deliver → Document → repeat. Include revenue targets for user's city.
3. **5-Minute Wins** — Catalog of quick actions. 4+ categories, 4+ items each.
4. **Content Leverage** — 1 input → 7+ outputs. Include weekly calendar.
5. **5-Level Autonomy** — L1 Operator → L5 Observer. Map user's tasks to levels.
6. **Inner/Outer Loop** — Human work vs agent work boundary.

### Business Mapping Frameworks (create during or after interview)

7. **Business Model Canvas** — 9 blocks from Osterwalder's Business Model Generation. Fill during interview: Value Propositions, Customer Segments, Channels, Revenue Streams, Key Resources, Key Activities, Key Partners, Cost Structure, Customer Relationships. Create as an interactive Obsidian note with a visual table layout.
8. **Value Proposition Canvas** — Zoom into the Customer Segments + Value Propositions blocks. Map: Customer Jobs, Pains, Gains vs. Products/Services, Pain Relievers, Gain Creators. Directly informs JTBD.
9. **Lean Canvas** — Ash Maurya's adaptation for solopreneurs. One-page: Problem, Solution, Key Metrics, Unique Value Proposition, Unfair Advantage, Channels, Customer Segments, Cost Structure, Revenue Streams.
10. **Revenue Model Map** — Visual breakdown of all revenue streams (cohorts, community, consulting, content, affiliates) with current and target amounts. Include sparklines on site.

11. **JTBD for Sales** — Apply switch forces (Push/Pull/Habit/Anxiety) from the Phase 1 interview as a sales conversation framework. Map common objections to JTBD responses. This note is auto-generated from `meta/jtbd.json`.

### Business Metrics Calculator (always create)

Create `frameworks/Business Metrics.md` — a living note with formulas and current numbers. Pre-populate from interview data where possible. Include Dataview inline fields so values can be queried.

**Unit Economics:**

| Metric | Formula | Example |
|--------|---------|---------|
| **CAC** (Customer Acquisition Cost) | Total marketing spend / New customers | €200 ads / 4 students = €50 |
| **LTV** (Lifetime Value) | Avg revenue per customer × Avg retention period | €950 × 1.5 cohorts = €1,425 |
| **LTV:CAC Ratio** | LTV / CAC (target: >3:1) | €1,425 / €50 = 28.5:1 |
| **Payback Period** | CAC / Monthly revenue per customer | €50 / €158 = 0.3 months |

**Revenue & Runway:**

| Metric | Formula |
|--------|---------|
| **MRR** (Monthly Recurring Revenue) | Community members × monthly price |
| **ARR** (Annual Recurring Revenue) | MRR × 12 |
| **Burn Rate** | Monthly expenses (rent + tools + insurance + tax reserve) |
| **Runway** | Cash reserves / Burn rate |
| **Break-even point** | Burn rate / Revenue per unit |
| **Revenue per hour** | Monthly revenue / Hours worked |

**Funnel Metrics:**

| Metric | Formula |
|--------|---------|
| **Conversion rate** | Sales / Leads × 100 |
| **Lead velocity** | (Leads this month − Leads last month) / Leads last month × 100 |
| **Pipeline value** | Σ (Lead × Probability × Deal size) |
| **Churn rate** | Lost customers / Total customers × 100 |
| **NPS** (Net Promoter Score) | % Promoters − % Detractors |

**Content ROI:**

| Metric | Formula |
|--------|---------|
| **Cost per content piece** | Time spent × Hourly rate |
| **Revenue per post** | Attributed revenue / Posts published |
| **Engagement-to-lead ratio** | Leads / Total engagements |
| **Content leverage ratio** | Output pieces / Input sessions |

Each metric should have: current value, target value, and a sparkline trend on the Astro site. Create tasks to update metrics monthly.

Ask the user which business frameworks to include. Default: Business Model Canvas + Lean Canvas + JTBD for Sales + Business Metrics. Create as fillable templates in `frameworks/` with the user's data from the interview pre-populated where possible.

### Task Frontmatter (Dataview-compatible)

```yaml
---
type: task
status: open          # open | done | archived
stage: engage         # create | publish | engage | convert | deliver | review
effort: 5min          # 5min | 15min | 30min | 1hr
priority: high        # high | medium | low
source: agent         # agent | manual
created: YYYY-MM-DD
due: YYYY-MM-DD
---
```

### Daily Dashboard

`Daily Dashboard.md` with Dataview queries showing: open tasks (LIMIT 5), completed by agents, stats, and sales cycle stage breakdown. Use Dataview TABLE queries with `FROM "tasks"`.

### Context Interview Template

`templates/Context Interview.md` — 10 minutes, 5 parts: Who You Are, What Hurts, What Success Looks Like, Boundaries, Quick-Fire. Designed to produce a `context.md` that agents can use.

## Phase 3: Deep Research

Launch 3+ parallel agents with the Agent tool. Topics depend on JTBD interview but typically:

1. **Location/market** — Cost of living, legal, tax, visa for user's city
2. **Industry** — Market size, pricing benchmarks, competitors
3. **Distribution** — Platform strategy (LinkedIn, YouTube, etc.) with weekly schedule

Each agent writes to `research/` with frontmatter including `type: research`, `domain`, `tags`, and wikilinks to frameworks. Also copy each research file to `site/src/content/research/` for the site.

## Phase 4: Astro Site

### Setup

```bash
npm create astro@latest site -- --template minimal --no-install --no-git --typescript strict
cd site && npm install && npm install @astrojs/mdx @astrojs/sitemap marked
```

### Template Assets

Copy from this skill's `assets/site-template/`:

| Source | Destination |
|--------|------------|
| `assets/site-template/src/styles/tufte.css` | `site/src/styles/` |
| `assets/site-template/src/components/*.astro` | `site/src/components/` |
| `assets/site-template/src/layouts/Base.astro` | `site/src/layouts/` |
| `assets/site-template/public/favicon.svg` | `site/public/` |

Customize `Base.astro`: update site title, nav links, and footer text for the user.

### Key Components

- **Sparkline.astro** — Inline SVG charts (bar, line, area). Props: `data: number[]`, `type`, `color`.
- **Sidenote.astro** — Tufte margin notes. Props: `id: string`.
- **Card.astro** — Status cards with tags. Props: `title`, `status`, `tags[]`, `href`.
- **Chart.astro** — Chart.js graphs (line, bar, doughnut, radar). Props: `type`, `labels: string[]`, `datasets: [{label, data, color}]`, `title`. Loads Chart.js from CDN. Use for revenue projections, funnel visualization, business metrics over time.

### Pages to Create

All pages are `.astro` files (not markdown). Use HTML tables, not markdown tables.

1. **`/`** — Hero, card grid of frameworks, key numbers with sparklines, research cards
2. **`/dashboard`** — Parse `src/content/tasks/*.md` via `import.meta.glob('...', { eager: true, query: '?raw', import: 'default' })`, render as cards sorted by priority
3. **`/frameworks`** — Card grid grouped by category
4. **`/frameworks/[name]`** — Individual pages with tables, sidenotes, sparklines, Chart.js graphs
5. **`/research/index`** — Dynamic card grid from `src/content/research/*.md` via `import.meta.glob`
6. **`/research/[slug]`** — Dynamic page: parse markdown with `marked`, render as HTML. Use `getStaticPaths()` to generate one page per research file. Strip wikilinks, parse frontmatter manually.
7. **`/agents`** — Agent overview with activity sparklines
7. **`/start`** — Context Interview as onboarding

### Task Sync for Dashboard

Copy vault `tasks/*.md` to `site/src/content/tasks/` before build. Parse frontmatter manually (not gray-matter in build — use `import.meta.glob` with `?raw` query).

## Phase 5: Deploy

### Vercel

```bash
cd site && npx vercel --prod --yes
npx vercel domains add <domain>    # if provided
```

### Git + GitHub

```bash
git init
echo "node_modules/\nsite/dist/\nsite/.vercel/\n.DS_Store" > .gitignore
git add -A && git commit -m "Initial vault: solopreneur ops with Astro site"
gh repo create <user>/<name> --public --source=. --push
```

### Deploy Script

Create `scripts/deploy-site.sh` that syncs tasks, builds, and deploys. Make executable.

## Phase 6: Scheduled Agents

Offer to create routines via `/schedule`:

| Routine | Schedule (UTC) | Purpose |
|---------|---------------|---------|
| LinkedIn Scanner | `0 5 * * 1-5` | Find engagement opportunities daily |
| Weekly Market Scan | `0 6 * * 1` | Competitor and trend monitoring |
| Biweekly Review | `0 7 1,15 * *` | Content performance + framework updates |

Each routine: clone repo → web search → create files → commit → push.

## Design Principles

1. **Max 5 items** on any dashboard (Dataview LIMIT 5)
2. **Auto-archive** tasks after 3 days
3. **Action before motivation** (Behavioral Activation)
4. **Dual audience** — humans read body, agents read frontmatter
5. **One source of truth** — vault is canonical, site is derived
6. **Agents research, humans decide** — never auto-send, auto-post, or auto-buy

## Reference

Live example: [solo.salient.community](https://solo.salient.community)
Source: [github.com/glebis/solopreneur-ops-vault](https://github.com/glebis/solopreneur-ops-vault)
